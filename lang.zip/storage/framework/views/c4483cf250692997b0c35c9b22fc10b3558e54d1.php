<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">


              <h5 class="card-title">Course wise Tabulation Sheet [Grade]</h5>
              <div class="mb-3">
                <a href="<?php echo e(url('admin/course_wise_tabulation_grade/download/'.$course_name.'/'.$batch_name)); ?>">Download Report </a>

              </div>
<pre>
<h4>
Course Name: <?php echo e(App\Models\Course::where('id',$course_name)->first()->name); ?>

Batch No: <?php echo e(App\Models\Batch::where('id',$batch_name)->first()->batch_name); ?>

</h4>
</pre>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th rowspan="2">SL</th>
                                <th rowspan="2">Name</th>
                                <th rowspan="2">Registration No</th>
                                <th colspan="<?php echo e(count($quizzes)+2+count($assignments)); ?>" class="text-center">Marks</th>
                            </tr>
                            <tr>
                                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <th><?php echo e($quiz->name); ?></th>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <th><?php echo e($assignment->title); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <th>CGPA</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($results['student_name']); ?></td>
                                <td><?php echo e($results['id']); ?></td>
                                <?php
                                    $cgpa=0;
                                    $i=0;
                                ?>

                                <?php $__currentLoopData = $results['quiz_marks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz_marks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <td><?php echo e(number_format($quiz_marks['gpa'],2)); ?></td>
                                  <?php
                                      $cgpa+=$quiz_marks['gpa'];
                                      $i+=1;
                                  ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php $__currentLoopData = $results['assignment_marks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <td><?php echo e(number_format($assignment['gpa'],2)); ?></td>
                                  <?php
                                  $cgpa+=$assignment['gpa'];
                                  $i+=1;
                                 ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e(number_format($cgpa/$i,2)); ?></td>
                                <?php if(($cgpa/$i) == 0): ?>

                                    <td colspan="5"  align="center"><?php echo e('F'); ?></td>

                            <?php elseif(($cgpa/$i) >= 2.50 && ($cgpa/$i) <=2.74 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('C+'); ?></td>

                            <?php elseif(($cgpa/$i) >= 2.75 && ($cgpa/$i) <=2.99 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('B-'); ?></td>

                            <?php elseif(($cgpa/$i) >= 3.00 && ($cgpa/$i) <=3.24 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('B'); ?></td>

                            <?php elseif(($cgpa/$i) >= 3.25 && ($cgpa/$i) <=3.49 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('B+'); ?></td>

                            <?php elseif(($cgpa/$i) >= 3.50 && ($cgpa/$i) <=3.74 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('A-'); ?></td>

                            <?php elseif(($cgpa/$i) >= 3.75 && ($cgpa/$i) <=3.99 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('A'); ?></td>

                            <?php elseif(($cgpa/$i) >= 4.00 ): ?>

                                    <td colspan="5"  align="center"><?php echo e('A+'); ?></td>
                            <?php else: ?>
                               <td colspan="5"  align="center"><?php echo e('Unsatisfactory'); ?></td>
                            <?php endif; ?>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/course_based_tabulation_sheet_grade.blade.php ENDPATH**/ ?>