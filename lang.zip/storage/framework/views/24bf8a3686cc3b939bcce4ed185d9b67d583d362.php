<?php $__env->startSection('content'); ?>
<div class="container-flex">
    <div class="row">
        <div class="col-lg-8">
            <div class="card-header"></div>
            <div class="card-body">
                <table class="table table-light">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Assignment Title</th>
                            <th>Course Name</th>
                            <th>Batch Name</th>
                            <th>Deadline</th>
                            <th>Full Marks</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = App\Models\CoursedBasedAssignment::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($test->title); ?></td>
                            <td><?php echo e($test->rel_to_course->name); ?></td>
                            <td><?php echo e($test->rel_to_batch->batch_name); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($test->deadline)->format('d-M-y')); ?></td>
                            <td><?php echo e($test->full_marks); ?></td>




                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No Assignment Created Yet</td>
                        </tr>

                        <?php endif; ?>

                    </tbody>
                </table>

            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-default">
                    <h3 id="q_title"><?php echo e('Create Course Based Test'); ?>

                    </h3>
                </div>
                <div class="card-body">
                        <form action="<?php echo e(route('course_based_assigmnet.post')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3 form-group">
                                <label for="" class="form-label">Assignment Title:</label>
                                <input type="text" value="<?php echo e(old('name')); ?>" required name="name" class="form-control form-control-rounded">
                            </div>
                            <div class="mb-3 form-group">
                                <label for="" class="form-label">Course Name:</label>
                                <select name="course_id"  id="course_id" class="form-control form-control-rounded" id="">
                                    <option value="">---Select Course Name---</option>
                                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div class="mb-3 form-group">
                                <label for="" class="form-label">Batch Name:</label>
                                <select name="batch_id" id="batch_id" class="form-control form-control-rounded" id="">
                                    <option value="">---Select Batch Name---</option>

                                </select>
                            </div>
                            <div class="mb-3 form-group">
                                <label for="" class="form-label">Upload File:</label>
                                <input type="file" name="file" class="form-control form-control-rounded" id="">
                            </div>
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <p class="text-danger"><?php echo e($message); ?></p>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="mb-3 form-group">
                                <label for="" class="form-label">
                                    Deadline
                                </label>
                                <input type="date" value="<?php echo e(old('deadline')); ?>" name="deadline" class="form-control form-control-rounded" id="">
                            </div>


                            <div class="m-3 form-group">
                                <label for="" class="form-label">Full Marks:</label>
                                <input type="number" value="<?php echo e(old('pass_marks')); ?>" required name="pass_marks" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <button type="submit" class="btn btn-success btn-rounded">Submit</button>
                            </div>
                        </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_code'); ?>

<script>
    $('#course_id').change(function(){
        var course_id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

     $.ajax({
        type:'POST',
        url:'/getBatch',
        data:{'course_id':course_id},
        success:function(data){
            $('#batch_id').html(data);
        }
    });
})
</script>


<?php if(session('success')): ?>

<script>
 const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 2500,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})
Toast.fire({
  icon: 'success',
  title: ' Added successfully'
})
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/assignment/index.blade.php ENDPATH**/ ?>