<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Assignments</h5>
                    <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="col-md-3">
                        <div class="card card__course">
                            <div class="card-header card-header-large card-header-dark bg-warning d-flex justify-content-center">
                                <a class="card-header__title  justify-content-center align-self-center d-flex flex-column" href="">
                                    <span></span>
                                    <span class="course__title"><?php echo e($assignment->title); ?></span>
                                    <span class="course__subtitle"><?php echo e($assignment->full_marks); ?></span>
                                </a>
                            </div>
                        <?php if(App\Models\CourseBasedAssignmentSubmission::where('student_id',$student['id'])->where('assignment_id',$assignment->id)->exists()): ?>
                        <div class="p-3">
                            <div class="d-flex align-items-center">
                               <b>Submitted</b>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="p-3">
                        <div class="mb-2">
                            Deadline:<?php echo e(Carbon\Carbon::parse($assignment->deadline)->format("d-M-y")); ?>

                        </div>
                        <div class="d-flex align-items-center">
                            <a href="<?php echo e(asset('assets/uploads/assignments/'.$assignment->file_name)); ?>" download="" class="btn btn-primary m-2">Download</a>
                            <a href="<?php echo e(route('assignment.student.index',$assignment->id)); ?>" class="btn btn-warning m-2">Submit</a>
                        </div>
                    </div>
                </div>

                    <?php endif; ?>
                   </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <p class="m-auto">No Assignments for today</p>
                    <?php endif; ?>
                </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/assignment/student_index.blade.php ENDPATH**/ ?>