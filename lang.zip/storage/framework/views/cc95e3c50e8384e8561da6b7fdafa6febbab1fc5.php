<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><h3>Edit Individual Quiz</h3></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('individualquiz.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($quiz->id); ?>" >
                        <div class="mb-3 form-group">
                            <label for="" class="form-label">Test Title:</label>
                            <input type="text" required name="name" value="<?php echo e($quiz->name); ?>" class="form-control form-control-rounded">
                        </div>
                        <div class="mb-3 form-group">
                            <label for="" class="form-label">Introduction Text:</label>
                            <input type="text" required value="<?php echo e($quiz->introduction_text); ?>" name="introduction_text" class="form-control form-control-rounded">
                        </div>
                        <div class="mb-3 form-group">
                            <label for="" class="form-label">Passing Comment:</label>
                            <input type="text" required value="<?php echo e($quiz->passing_comments); ?>" name="pass_comment" class="form-control form-control-rounded">
                        </div>
                        <div class="mb-3 form-group">
                            <label for="" class="form-label">Fail Comment:</label>
                            <input type="text" required value="<?php echo e($quiz->failing_comments); ?>" name="failing_comment" class="form-control form-control-rounded">
                        </div>
                        <div class="mb-3 form-group">
                            <label for="" class="form-label">Time(In Minutes):</label>
                            <input type="integer" required name="time" value="<?php echo e($quiz->time); ?>" class="form-control form-control-rounded">
                        </div>

                        <div class="row form-group">
                            <div class="m-3 form-group">
                                <label for="" class="form-label">Start Date:</label>
                                <input type="date" value="<?php echo e($quiz->start_date); ?>" required name="start_date" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <label for="" class="form-label">Start time:</label>
                                <input type="time" value="<?php echo e($quiz->start_time); ?>" required name="start_time" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <label for="" class="form-label">End Date:</label>
                                <input type="date" value="<?php echo e($quiz->end_date); ?>" required name="end_date" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <label for="" class="form-label">End time:</label>
                                <input type="time" value="<?php echo e($quiz->end_time); ?>" required name="end_time" class="form-control form-control-rounded">
                            </div>
                        </div>

                        <div class="m-3 form-group">
                            <label for="" class="form-label">Pass Marks:</label>
                            <input type="number" required value="<?php echo e($quiz->pass_marks); ?>"name="pass_marks" class="form-control form-control-rounded">
                        </div>
                        <div class="m-3 form-group">
                            <button type="submit" class="btn btn-success btn-rounded">Submit</button>
                        </div>
                    </form>

                </div>



            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/individual_test/edit.blade.php ENDPATH**/ ?>