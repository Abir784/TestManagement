<?php $__env->startSection('content'); ?>
<div class="container-flex">


    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-default">
                    <h3 id="q_title"><?php echo e('Create Matching Questions'); ?>

                    </h3>
                    <button class="ml-2 btn btn-primary" value="1">MCQ</button>
                    <button class="ml-2 btn btn-primary" value="2">Descriptive</button>
                    <button class="ml-2 btn btn-primary" value="3">Fill in blank</button>
                    <button class="ml-2 btn btn-primary" value="4">Matching</button>
                </div>
                <div class="card-body">
                        <form action="<?php echo e(route('question.post')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="module_id" value="<?php echo e($module_id); ?>" id="">
                            <div class="fields">
                                <p class='text-danger'>*If there are more than one answers in the question please separate the answers with Hash(#) , if there is partial marking please give the marks for each option in order separated by Hash(#).</p>
                                <input type='hidden' name='type' value='MATCH' >
                                <div class="mb-3 form-group">

                                    <label for=""><b>Create Matching:</b></label>
                                    <textarea name="title" id="editor" class="form-control"></textarea>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <b class="text-danger"> <?php echo e($message); ?> </b>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3 form-group">
                                    <label for="" class="form-label">Answers</label>
                                    <input type="text" name="answers" id="" class="form-control form-control-rounded">
                                    <?php $__errorArgs = ['answers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <b class="text-danger"> <?php echo e($message); ?> </b>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="mb-3">
                                    <label for="" class="form-label"><b>Total Marks:</b></label>
                                    <input type="text" name="marks"  class="form-control">
                                    <?php $__errorArgs = ['marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <b class="text-danger">  <?php echo e($message); ?> </b>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class='mb-3 form-group'>
                                <button class='btn btn-success btn-rounded' type='submit'>Submit</button>

                            </div>
                        </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_code'); ?>
<script>
$(document).ready(function(){
    $('button').click(function(){
        var val = $(this).val();
        if (val==1){
            data="<p class='text-danger'>If there are more than one answers in the question please separate the answers with Hash(#) , if there is partial marking please give the marks for each option in order separated by Hash(#).</p><input type='hidden' name='type' value='MCQ' id='><div class='mb-3 form-group'><label for=' class='form-label'><b>Question Title:</b></label><textarea name='title' id='editor1' value='<?php echo e(old('title')); ?>' class='form-control form-control-rounded'></textarea><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><b class='mb-2 text-danger'><?php echo e($message); ?></b> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div><div class='mb-3 form-group'><label for='' class='form-label'><b>  Options:</b> </label><textarea value='<?php echo e(old('option')); ?>'  name='option' id='editor2' class='form-control form-control-rounded'></textarea><?php $__errorArgs = ['option1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><b class='mt-2 text-danger'><?php echo e($message); ?></b><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div><div class='mb-3 form-group'><label for='' class='form-label'><b> Correct Answers:</b> </label><textarea value='<?php echo e(old('correct_answer')); ?>'  name='correct_answer' id='editor2' class='form-control form-control-rounded'></textarea><?php $__errorArgs = ['correct_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><b class='mt-2 text-danger'><?php echo e($message); ?></b><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div><div class='mr-3 form-group'><label class='form-label'><b>Marks:</b></label><input required type='text' name='marks' class='form-control form-control-rounded'></div>"
            $('.fields').html(data);
            $('#q_title').html('Create MCQ Questions')


        }else if (val==2) {
            var data="<input type='hidden' name='type' value='DESC'><div class='m-3 form-group><label class='form-label'><b>Enter Question:</b></label><textarea required id='editor1' type=text name=title class='form-control form-control-rounded'></textarea><div class='mr-3 form-group'><label class='form-label'><b>Marks:</b></label><input type='text' required name='marks' class='form-control form-control-rounded'></div>";
            $('.fields').html(data);
            $('#q_title').html('Create Descriptive Questions')
        }else if(val==3){
            var data="<p class='text-danger'>*If there are more than one answers in the question please separate the answers with Hash(#) , if there is partial marking please give the marks for each option in order separated by Hash(#).</p><input type='hidden' name='type' value='FILL'><div class='m-3 form-group><label class='form-label'><b>Fill in the Blanks:</b></label><textarea required id='editor1' type=text name=title class='form-control form-control-rounded'></textarea><div class='mt-3 form-group'><label class='form-label'><b>Answers:</b></label><input name='answer' required class='form-control form-control-rounded' type='text'></div><div class='mr-3 form-group'><label class='form-label'><b>Marks:</b></label><input required type='text' name='marks' class='form-control form-control-rounded'></div>";
            $('.fields').html(data);
            $('#q_title').html('Create Fill In The Blank Questions')
        }else if(val==4){
            location.reload();
        };
    })
});
</script>


<script>

ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );

 </script>


<?php if(session('success')): ?>

<script>
 const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 2500,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})
Toast.fire({
  icon: 'success',
  title: 'Question Added successfully'
})
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/question_bank/question/index.blade.php ENDPATH**/ ?>