<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Exam Schedules</h5>
                    <p class="card-text">

                        <form action="<?php echo e(url('admin/course_wise_exam_schedule/post')); ?>" method="POST" enctype="multipart/form-data" >
                          <?php echo csrf_field(); ?>
                          <div class="mb-3 form-group">
                            <label for="" class="form-lable">Select Course </label>
                            <select name="course_id" class="form-control form-control-rounded" id="course_id">
                                <option value="">--Select Course Name--</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <b class="text-red"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="mb-3 form-group">
                            <label for="" class="form-lable">Select Batch </label>
                            <select name="batch_id" class="form-control form-control-rounded" id="batch_id">
                                <option value="">--Select Batch Name--</option>
                            </select>
                            <?php $__errorArgs = ['batch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <b class="text-red"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 form-group">
                            <button class="btn btn-success btn-rounded">Submit</button>
                        </div>

                     </form>

                    </p>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_code'); ?>
<script>
    $('#course_id').change(function(){
        var course_id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

     $.ajax({
        type:'POST',
        url:'/getBatch',
        data:{'course_id':course_id},
        success:function(data){
            $('#batch_id').html(data);
        }
    });
})
</script>

<script>
    $('#batch_id').change(function(){
        var batch_id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

     $.ajax({
        type:'POST',
        url:'/getQuiz',
        data:{'batch_id':batch_id},
        success:function(data){
            $('#quiz_id').html(data);
        }
    });
})
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/exam_schedule/exam_schedule_index.blade.php ENDPATH**/ ?>