<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><h3>Postpone Course Based Quiz</h3></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('course_based_quiz.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($quiz->id); ?>" >
                        <div class="row form-group">
                            <div class="m-3 form-group">
                                <label for="" class="form-label"> New Start Date:</label>
                                <input type="date" value="<?php echo e($quiz->start_date); ?>" required name="start_date" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <label for="" class="form-label">New Start time:</label>
                                <input type="time" value="<?php echo e($quiz->start_time); ?>" required name="start_time" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <label for="" class="form-label">New End Date:</label>
                                <input type="date" value="<?php echo e($quiz->end_date); ?>" required name="end_date" class="form-control form-control-rounded">
                            </div>

                            <div class="m-3 form-group">
                                <label for="" class="form-label">New End time:</label>
                                <input type="time" value="<?php echo e($quiz->end_time); ?>" required name="end_time" class="form-control form-control-rounded">
                            </div>
                            <div class="m-3 form-group">
                                <label for="" class="form-label">Reason/Remarks:</label>
                                <input type="text" class="form-control form-control-rounded" name="reason">
                            </div>
                        </div>


                        <div class="m-3 form-group">
                            <button type="submit" class="btn btn-success btn-rounded">Submit</button>
                        </div>
                    </form>

                </div>



            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/course_based_test/edit.blade.php ENDPATH**/ ?>