<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Course Wise Absent List</h5>
                <div class="mb-3">
                    <a href="<?php echo e(url('admin/course_wise_absent_sheet/download/'.$course_id.'/'.$batch_id)); ?>">Download Report</a>
                </div>

<pre>
    <h4>
        Course Name:<?php echo e(App\Models\Course::where('id',$course_id)->first()->name); ?>

        Batch No:<?php echo e(App\Models\Batch::where('id',$batch_id)->first()->batch_name); ?>


    </h4>

</pre>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Registration No.</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Absent Exam Title</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $absent_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$absent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($absent['student_name']); ?></td>
                                <td><?php echo e($absent['id']); ?></td>
                                <td><?php echo e($absent['email']); ?></td>
                                <td><?php echo e($absent['phone']); ?></td>
                                <td><?php echo e($absent['quiz_name']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>



                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/attandence_sheets/course_wise_absent_list.blade.php ENDPATH**/ ?>