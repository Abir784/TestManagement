<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">


              <h5 class="card-title">Exam Schedule</h5>
              <div class="mb-3">
                <a href="<?php echo e(url('admin/course_wise_exam_schedule/download/'.$course_id.'/'.$batch_id)); ?>">Download Report </a>

              </div>
<pre>
<h4>
Course Name: <?php echo e(App\Models\Course::where('id',$course_id)->first()->name); ?>

Batch No: <?php echo e(App\Models\Batch::where('id',$batch_id)->first()->batch_name); ?>

</h4>
</pre>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th >Name Of Assesment</th>
                                <th >Syllabus Covered</th>
                                <th colspan="4" class="text-center">No of Questions</th>
                                <th colspan="4" class="text-center" >Marks</th>
                                <th>Time</th>
                                <th>Date</th>
                            </tr>
                            <tr>
                                <th></th>
                                <th></th>
                                <th>Desciptive</th>
                                <th>MCQ</th>
                                <th>Fill In the Blanks</th>
                                <th>Matching</th>

                                <th>Desciptive</th>
                                <th>MCQ</th>
                                <th>Fill In the Blanks</th>
                                <th>Matching</th>
                                <th></th>
                                <th></th>
                            </tr>

                        </thead>
                        <tbody>
                            <?php
                                $total_marks=0;
                            ?>
                        <?php $__currentLoopData = $quiz_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($quiz['quiz_name']); ?></td>
                            <td>
                                <?php $__currentLoopData = $quiz['module']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($module); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($quiz['desc']); ?></td>
                            <td><?php echo e($quiz['mcq']); ?></td>
                            <td><?php echo e($quiz['fill']); ?></td>
                            <td><?php echo e($quiz['match']); ?></td>


                            <td><?php echo e($quiz['desc_marks']); ?></td>
                            <td><?php echo e($quiz['mcq_marks']); ?></td>
                            <td><?php echo e($quiz['fill_marks']); ?></td>
                            <td><?php echo e($quiz['match_marks']); ?></td>
                            <td><?php echo e($quiz['time']); ?> Min</td>
                            <td><?php echo e(Carbon\Carbon::parse($quiz['date'])->format('d-M-Y')); ?></td>
                            <?php
                                $total_marks+=($quiz['desc_marks']+$quiz['mcq_marks']+$quiz['fill_marks']+$quiz['match_marks']);
                            ?>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <b>Assignment:</b> <?php echo e($assignment->title); ?></td>
                            <td colspan="10" align="center" >Marks: <?php echo e($assignment->full_marks); ?></td>
                            <td> <b>Deadline: </b> <?php echo e(Carbon\Carbon::parse($assignment->deadline)->format('d-M-Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="12" align="center">Total Mark = <?php echo e($total_marks+$assignment_full_mark); ?></th>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/exam_schedule/exam_schedule_sheet.blade.php ENDPATH**/ ?>