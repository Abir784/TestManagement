<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Add Questions(Specific)</h5>
                    <p class="card-text">

                        <form action="<?php echo e(route('course_based.specific.quiz.question.post')); ?>" method="POST" enctype="multipart/form-data" >
                          <?php echo csrf_field(); ?>
                          <div class="mb-3 form-group">
                            <input type="hidden" name="quiz_id" value="<?php echo e($id); ?>">
                            <label for="" class="form-lable">Select Question Subject </label>
                            <select name="subject_id" class="form-control form-control-rounded" id="subjectid">
                                <option value="">--select subject--</option>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <b class="text-red"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="mb-3 form-group">
                            <label for="" class="form-lable">Select Module </label>
                            <select name="module_id" class="form-control form-control-rounded" id="module_id">
                                <option value="">--Select module--</option>
                            </select>
                            <?php $__errorArgs = ['module_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <b class="text-red"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 form-group">
                            <button class="btn btn-success btn-rounded">Submit</button>
                        </div>

                        </form>

                    </p>
                </div>
            </div>
    </div>
        <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Questions(Random)</h5>
                        <p class="card-text">

                            <form action="<?php echo e(route('course_based.quiz.question.post')); ?>" method="POST" enctype="multipart/form-data" >
                              <?php echo csrf_field(); ?>
                              <div class="mb-3 form-group">
                                <input type="hidden" name="quiz_id" value="<?php echo e($id); ?>">
                                <label for="" class="form-lable">Select Question Subject </label>
                                <select name="subject_id" required class="form-control form-control-rounded" id="subjectid2">
                                    <option value="">--select subject--</option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3 form-group">
                                <label for="" class="form-lable">Select Module </label>
                                <select name="module_id" required  class="form-control form-control-rounded" id="module_id2">
                                    <option value="">--Select module--</option>
                                </select>
                            </div>
                            <div class="mb-3 form-group">
                                <label for="">Question Number</label>
                                <input type="number" required  value="" name="q_no" class="form-control" >

                            </div>
                            <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                            <?php endif; ?>
                            <div class="mb-3 form-group">
                                <button class="btn btn-success btn-rounded">Submit</button>
                            </div>

                            </form>

                        </p>
                    </div>
                </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_code'); ?>
<script>
    $('#subjectid').change(function(){
        var subject_id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

     $.ajax({
        type:'POST',
        url:'/getModule',
        data:{'subject_id':subject_id},
        success:function(data){
            $('#module_id').html(data);
        }
    });
})
</script>

<script>
    $('#subjectid2').change(function(){
        var subject_id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

     $.ajax({
        type:'POST',
        url:'/getModule',
        data:{'subject_id':subject_id},
        success:function(data){
            $('#module_id2').html(data);
        }
    });
})
</script>
<?php if(session('success')): ?>

<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 2500,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
   Toast.fire({
       icon: 'success',
       title: 'Question Added successfully'
    })
   </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/course_based_test/question_add.blade.php ENDPATH**/ ?>