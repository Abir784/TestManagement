<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Independent Descriptive Answers Marking</h5>
                    <p class="card-text"></p>
                   <table class="table table-light">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Student Name</th>
                            <th>Quiz Title </th>
                            <th>Question Title</th>
                            <th>Full Marks</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($answer->rel_to_student->name); ?></td>
                            <td><?php echo e($answer->rel_to_quiz->name); ?></td>
                            <td><?php echo e($answer->rel_to_question->title); ?></td>
                            <td><?php echo e($answer->rel_to_question->marks); ?></td>
                            <td><a href="<?php echo e(route('independent.marking',$answer->id)); ?>" class="btn btn-outline-primary btn-rounded mr-3">Examine</a></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="m-auto">No Submissions Yet</td>
                        </tr>

                        <?php endif; ?>
                        <tr>
                            <td></td>
                        </tr>
                    </tbody>
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tests/descriptive_index.blade.php ENDPATH**/ ?>