<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                     <h3>
                        Course List
                     </h3>

                    </div>
                    <table class="table table-striped">
                        <tr>
                            <th>#</th>
                            <th>Course Name</th>
                            <th>Course Code</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>

                        <?php $__empty_1 = true; $__currentLoopData = $course_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($course->name); ?></td>
                            <td><?php echo e($course->course_code); ?></td>
                            <td><?php echo e(($course->created_at)->format('d M,Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('course.delete', $course->id)); ?>" class="mr-2 btn btn-outline-danger btn-rounded show_confirm"> Delete</a>
                                <a href="<?php echo e(route('course.edit', $course->id)); ?>" class="mr-2 btn btn-outline-info btn-rounded show_confirm"> Edit</a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5"> No data to show</td>
                        </tr>

                        <?php endif; ?>


                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_code'); ?>
<?php if(session('sucess')): ?>
<script>
$(document).ready(function(){
    Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Your data has been deleted',
  showConfirmButton: false,
  timer: 2500
})
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/course/course_list.blade.php ENDPATH**/ ?>