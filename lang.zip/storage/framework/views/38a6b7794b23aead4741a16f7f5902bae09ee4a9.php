<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">

                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(url('admin/course_wise_exam_postponed_list/download/'.$from.'/'.$to)); ?>">Download Report </a>

                      </div>
                    <h5 class="card-title">Postponed Exam List</h5>
                    <p class="card-text">
                        <table class="table table-light">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th>Course Name</th>
                                    <th>Batch Name</th>
                                    <th>Exam  Name</th>
                                    <th>Scheduled Date</th>
                                    <th>New Date</th>
                                    <th>Reason/Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $postponed_exam_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($exam['course_name']); ?></td>
                                    <td><?php echo e($exam['batch_name']); ?></td>
                                    <td><?php echo e($exam['quiz_name']); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($exam['scheduled_date'])->format('d-M-Y')); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($exam['new_date'])->format('d-M-Y')); ?></td>
                                    <td><?php echo e($exam['reason']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>


                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/exam_schedule/postponed_exam_list.blade.php ENDPATH**/ ?>