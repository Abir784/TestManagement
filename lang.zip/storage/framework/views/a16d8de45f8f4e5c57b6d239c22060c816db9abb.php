<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Certificate</h5>
                    <p class="card-text">

                        <div class="mb-3">
                            <?php if($bool): ?>
                              <img src="<?php echo e(asset('certificates/'.$image_name)); ?>" class="text-center" height="700px" width="500px" alt="<?php echo e($image_name); ?>">

                              <div class="m-3">
                                <a href="<?php echo e(asset('certificates/'.$image_name)); ?>" download="" class="btn btn-primary">Download Certificate</a>
                              </div>
                            <?php else: ?>
                            <h4>You have to attend all assesments to get a certificate..</h4>
                            <?php endif; ?>
                        </div>



                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/student/certificate_index.blade.php ENDPATH**/ ?>