<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Individual Exam Attendance Sheet</h5>
                    <p class="card-text">
                        <form action="<?php echo e(url('admin/individual_attendance_sheet/post')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="" class="form-label">Enter Student's Resgistration No\Id:</label>
                                <input type="text" name="student_id" class="form-control">
                                <?php if(session('error')): ?>
                                  <p class="text-danger"><?php echo e(session('error')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/attandence_sheets/individual_attendance_index.blade.php ENDPATH**/ ?>