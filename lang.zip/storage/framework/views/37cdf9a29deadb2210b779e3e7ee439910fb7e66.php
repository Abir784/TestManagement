<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">


              <h5 class="card-title">Course wise Result Sheet</h5>
              <div class="mb-3">
                <a href="<?php echo e(url('admin/course_wise_result_sheet/download/'.$course_name.'/'.$batch_name)); ?>">Download Report </a>

              </div>
<pre>
<h4>
Course Name: <?php echo e(App\Models\Course::where('id',$course_name)->first()->name); ?>

Batch No: <?php echo e(App\Models\Batch::where('id',$batch_name)->first()->batch_name); ?>

</h4>
</pre>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th >SL</th>
                                <th >Name</th>
                                <th >Registration No</th>
                                <th >CGPA</th>
                                <th >Grade</th>
                            </tr>

                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($results['student_name']); ?></td>
                                <td><?php echo e($results['id']); ?></td>
                                <td><?php echo e(number_format($results['cgpa'],2)); ?></td>
                             <?php if(($results['cgpa']) == 0): ?>

                                    <td align="center"><?php echo e('F'); ?></td>

                            <?php elseif(($results['cgpa']) >= 2.50 && ($results['cgpa']) <=2.74 ): ?>

                                    <td align="center"><?php echo e('C+'); ?></td>

                            <?php elseif(($results['cgpa']) >= 2.75 && ($results['cgpa']) <=2.99 ): ?>

                                    <td align="center"><?php echo e('B-'); ?></td>

                            <?php elseif(($results['cgpa']) >= 3.00 && ($results['cgpa']) <=3.24 ): ?>

                                    <td align="center"><?php echo e('B'); ?></td>

                            <?php elseif(($results['cgpa']) >= 3.25 && ($results['cgpa']) <=3.49 ): ?>

                                    <td align="center"><?php echo e('B+'); ?></td>

                            <?php elseif(($results['cgpa']) >= 3.50 && ($results['cgpa']) <=3.74 ): ?>

                                    <td align="center"><?php echo e('A-'); ?></td>

                            <?php elseif(($results['cgpa']) >= 3.75 && ($results['cgpa']) <=3.99 ): ?>

                                    <td align="center"><?php echo e('A'); ?></td>

                            <?php elseif(($results['cgpa']) >= 4.00 ): ?>

                                    <td align="center"><?php echo e('A+'); ?></td>
                            <?php else: ?>
                               <td colspan="5"  align="center"><?php echo e('Unsatisfactory'); ?></td>
                            <?php endif; ?>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/course_based_result_sheet.blade.php ENDPATH**/ ?>