<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body">
                    <div class="mb-3">
                        <?php if(session('success')): ?>
                          <div class="alert alert-success">

                             <br>Your tentative mark is <?php echo e(session('success')); ?>.
                          </div>

                        <?php endif; ?>

                    </div>
                <div class="card-title"><?php echo e(__('Dashboard')); ?></div>
                <?php echo e("----Your Info----"); ?><br>
                <?php echo e("Name: ". Auth::user()->name); ?> <br>
                <?php echo e("Email: ". Auth::user()->email); ?> <br>
                <?php if(Auth::user()->role == 2): ?>
                <?php echo e("Role: ". 'Student'); ?>

                <?php elseif(Auth::user()->role == 3): ?>
                <?php echo e("Role: ". 'Instructor'); ?>


                <?php endif; ?>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/auth/student/dashboard.blade.php ENDPATH**/ ?>