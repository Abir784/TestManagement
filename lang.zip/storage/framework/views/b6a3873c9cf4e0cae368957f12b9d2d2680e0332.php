<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-14">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <h3>Student List</h3><br>
                    </div>

                    <table class="table table-striped">
                        <tr>
                            <th>#</th>
                            <th>Student Name</th>
                            <th>Email</th>
                            <th>Registration no.</th>
                            <th>Phone no.</th>
                            <th>Course Name</th>
                            <th>Batch Name</th>
                            <th>Enrolled At</th>
                            <th>Action</th>
                        </tr>

                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->email); ?></td>
                            <td><?php echo e($student->registration_no); ?></td>
                            <td><?php echo e($student->phone_no); ?></td>
                            <td><?php echo e($student->course_name->name); ?></td>
                            <td><?php echo e($student->batch_name->batch_name); ?></td>
                            <td><?php echo e(($student->created_at)->format('d M,Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('student.delete', $student->user_id)); ?>" class="mb-2 btn btn-outline-danger btn-rounded show_confirm"> Delete</a>
                                <a href="<?php echo e(route('student.edit', $student->user_id)); ?>" class="mb-2 btn btn-outline-info btn-rounded show_confirm"> Edit</a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9"> No data to show</td>
                        </tr>

                        <?php endif; ?>


                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_code'); ?>
<?php if(session('success')): ?>
<script>
$(document).ready(function(){
    Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Your data has been deleted',
  showConfirmButton: false,
  timer: 2500
})
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/student/students_list.blade.php ENDPATH**/ ?>