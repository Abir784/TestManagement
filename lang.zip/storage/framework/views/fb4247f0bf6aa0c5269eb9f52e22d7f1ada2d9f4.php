<?php $__env->startSection('content'); ?>
<div class="flex-container">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e('Subjects'); ?>

                    </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th class="col">Subject Name</th>
                            <th class="col">Description</th>
                            <th class="col">Created At</th>
                            <th class="col">Action</th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($subject->name); ?></td>
                            <td><?php echo e($subject->desp !=null ? $subject->desp : 'N/A'); ?></td>
                            <td><?php echo e(($subject->created_at)->format('d/m/Y')); ?></td>
                            <td><a href="<?php echo e(route('subject.delete', $subject->id)); ?>" class="mr-2 btn btn-outline-danger btn-rounded show_confirm"> Delete</a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No data </td>
                        </tr>

                        <?php endif; ?>



                    </table>

                </div>
            </div>

        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-default">
                    <h3><?php echo e('Create Subject'); ?>

                    </h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('subject.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3 form-group">
                            <label for="" id="" class="form-label">
                                <b>Subject Name:</b>
                            </label>
                            <input type="text" value="<?php echo e(old('name')); ?>"  name="name" id="" class="form-control form-control-rounded ">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <b class="mb-2 text-danger"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 form-group">
                            <label for="" class="form-label">
                              <b>  Description:</b>
                            </label>
                            <input type="text" value="<?php echo e(old('desp')); ?>"  name="desp" id="" class="form-control form-control-rounded ">
                            <?php $__errorArgs = ['desp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <b class="mt-2 text-danger"><?php echo e($message); ?></b>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3 form-group">
                            <button class="btn btn-success btn-rounded" type="submit">Submit</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_code'); ?>
<?php if(session('success')): ?>

<script>
 const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 2500,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})
Toast.fire({
  icon: 'success',
  title: 'Subject Added successfully'
})
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/question_bank/subject/index.blade.php ENDPATH**/ ?>