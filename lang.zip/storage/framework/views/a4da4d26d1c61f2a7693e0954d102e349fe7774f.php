<?php $__env->startSection('content'); ?>


<div class="container-fluid page__container">
    <div class="mb-6 float-end">
        <h5>Time Left:</h5>
       <h6><p id="timer" class="float-end"></p></h6>
    </div>
    <div id="questions_wrapper">

    <form id="exam_form" action="<?php echo e(route('student.exam.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="quiz_id" value="<?php echo e($id); ?>">
        <input type="hidden" name="quiz_type" value="2">


        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <input type="hidden" name="question_id[]" value="<?php echo e($question->question_id); ?>">
        <div class="card mb-4" data-position="1" data-question-id="1">
            <div class="card-header d-flex justify-content-between">

                <div class="d-flex align-items-center ">

                    <span class="question_handle btn btn-sm btn-secondary">
                        <i class="material-icons">menu</i>
                    </span>
                    <div class="h4 m-0 ml-4">Q <?php echo e($key+1); ?>: <?php echo $question->rel_to_question->title; ?></div>
                </div>
            </div>
            <div class="card-body">

                <div id="answerWrapper_1" class="mb-4">
                    <div class="row mb-1">
                        <div class="col"><strong></strong></div>
                        <div class="col text-right"><strong></strong></div>
                    </div>
                    <?php if($question->rel_to_question->type =='MCQ'): ?>
                    <ul class="list-group" id="answer_container_1">
                        <?php $__currentLoopData = App\Models\QuestionOptions::where('question_id',$question->rel_to_question->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li class="list-group-item d-flex" data-position="1" data-answer-id="1" data-question-id="1">
                            <span class="mr-2"><i class="material-icons text-light-gray">menu</i></span>
                            <div>
                               <?php echo e($options->option_title); ?>

                            </div>
                            <div class="ml-auto">
                                <input type="checkbox" name="answer_.<?php echo e($question->question_id); ?>[]" value="<?php echo e($options->id); ?>">
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                    <?php elseif($question->rel_to_question->type =="DESC"): ?>
                      <textarea class="form-control" name="answer_.<?php echo e($question->question_id); ?>"></textarea>
                    <?php elseif($question->rel_to_question->type == "MATCH"): ?>
                      <?php
                      $option_count=count(App\Models\QuestionOptions::where('question_id',$question->rel_to_question->id)->get());
                      ?>
                      <?php for($i=1;$i<=$option_count;$i++): ?>
                            <div class="mt-3">

                            <?php echo e('Answer No.'.$i); ?> <input class="form-control" type="text" name="answer_.<?php echo e($question->question_id); ?>[]">
                            </div>
                      <?php endfor; ?>
                    <?php elseif($question->rel_to_question->type == "FILL"): ?>

                    <?php
                    $option_count=count(App\Models\QuestionOptions::where('question_id',$question->rel_to_question->id)->get());
                    ?>
                    <?php for($i=1;$i<=$option_count;$i++): ?>
                          <div class="mt-3">

                          <?php echo e('Answer No.'.$i); ?> <input class="form-control" type="text" name="answer_.<?php echo e($question->question_id); ?>[]">
                          </div>
                    <?php endfor; ?>


                    <?php endif; ?>



                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3">
            <button type="submit" class="btn btn-success">Submit</button>

        </div>

    </form>


    </div>
</div>


</div>
<!-- // END drawer-layout__content -->

<div class="mdk-drawer  js-mdk-drawer" id="default-drawer" data-align="start">
<div class="mdk-drawer__content">
    <div class="sidebar sidebar-light sidebar-left bg-white" data-perfect-scrollbar>


        <div class="sidebar-block p-0 m-0">
            <div class="d-flex align-items-center sidebar-p-a border-bottom bg-light">
                <a href="#" class="flex d-flex align-items-center text-body text-underline-0">
                    <span class="avatar avatar-sm mr-2">
                        <span class="avatar-title rounded-circle bg-soft-secondary text-muted">AD</span>
                    </span>
                    <span class="flex d-flex flex-column">
                        <strong>Adrian Demian</strong>
                        <small class="text-muted text-uppercase">Instructor</small>
                    </span>
                </a>
                <div class="dropdown ml-auto">
                    <a href="#" data-toggle="dropdown" data-caret="false" class="text-muted"><i class="material-icons">more_vert</i></a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="student-dashboard.html">Dashboard</a>
                        <a class="dropdown-item" href="student-profile.html">My profile</a>
                        <a class="dropdown-item" href="student-edit-account.html">Edit account</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" rel="nofollow" data-method="delete" href="login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_code'); ?>
<script>
  const myTimeout = setTimeout(myGreeting, <?php echo e($time); ?>*60000);

        function myGreeting() {

            // window.location.replace("/student/CourseBased/Quiz/timeout/"+<?php echo e($id); ?>);
            document.getElementById("exam_form").submit();

        }
</script>
<script>
    setInterval(displayHello, 1000);
    var start=<?php echo e($time); ?>*60;


    function displayHello() {
       start-=1;
      document.getElementById("timer").innerHTML = start+" Seconds";
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/course_based_test/exam_page.blade.php ENDPATH**/ ?>