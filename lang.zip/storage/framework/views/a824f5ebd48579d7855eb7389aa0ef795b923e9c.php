<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header"><h3>Question</h3></div>
                <div class="card-body">
                    <table class="table table-light">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Question Name</th>
                                <th>Question Type</th>
                                <th>Answers</th>
                                <th>Total Marks</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo $data['title']; ?></td>
                                <td><?php echo $data['type']; ?></td>
                                <td>
                                    <?php if($data['count']>0): ?>
                                      <?php if($data['type']=='MATCH'): ?>
                                      <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(($key+1)==count($data['options'])): ?>

                                        <?php echo e($option['option_title']); ?>


                                        <?php else: ?>
                                        <?php echo e($option['option_title'].'-'); ?>

                                        <?php endif; ?>


                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                      <?php else: ?>

                                      <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($option['right_answer']==1): ?>

                                      <?php echo $option['option_title'].'<button class="m-2 btn btn-sm btn-success" disable></button><br>'; ?>


                                      <?php else: ?>
                                      <?php echo $option['option_title'].'<br>'; ?>

                                      <?php endif; ?>

                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    
                                    <?php echo e($data['total_marks']); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('question.delete', $data['question_id'])); ?>" class="btn btn-danger"> Delete</a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5"> No Data</td>
                            </tr>

                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/question_bank/question/question_list.blade.php ENDPATH**/ ?>