<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(url("admin/course_wise_exam_date_range_schedule/download/".$from."/".$to)); ?>">Download Report</a>
                    </div>
                    <h5 class="card-title">Exam Schedule [Date Range]</h5>
                    <p class="card-text">
                        <table class="table table-light">
                            <thead class="thead-light">
                                   <th>Course Name</th>
                                   <th>Batch Name</th>
                                   <th class="text-center" colspan="<?php echo e(count($dates)); ?>">Date & Time</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $exam_schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($exams['course_name']); ?>

                                    </td>

                                    <td>
                                        <?php echo e($exams['batch_name']); ?>

                                    </td>
                                    <?php $__currentLoopData = $exams['tests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <td>
                                           From: (<?php echo e(Carbon\Carbon::parse($exam['start_date'])->format('d-M-Y')); ?>|<?php echo e(Carbon\Carbon::parse($exam['start_time'])->format('h:i A')); ?>)<br>To:(<?php echo e(Carbon\Carbon::parse($exam['end_date'])->format('d-M-Y')); ?>|<?php echo e(Carbon\Carbon::parse($exam['end_time'])->format('h:i A')); ?>)
                                       </td>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tr>



                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>


                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/exam_schedule/exam_schedule_date_range_sheet.blade.php ENDPATH**/ ?>