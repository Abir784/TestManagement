<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(url('admin/individual_attendance_sheet/download/'.$attendances['s_id'])); ?>">Download Report</a>
                    </div>
                    <h5 class="card-title">Individual Attandance Sheet</h5>
                    <p class="card-text">


<pre>
<h4>
Name of Delegate: <?php echo e($attendances['name']); ?>

Course Name: <?php echo e($attendances['course_name']); ?>

Batch No: <?php echo e($attendances['batch_name']); ?>

</h4>


</pre>
                     <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Exam Title</th>
                                <th>Date Of Exam</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $attendances['tests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$tests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($tests['quiz_name']); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($tests['start_date'])->format('d-M-Y')); ?></td>
                                <td><?php echo e($tests['status']); ?></td>
                            </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                     </table>


                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/tabulation/attandence_sheets/individual_attandance_sheet.blade.php ENDPATH**/ ?>