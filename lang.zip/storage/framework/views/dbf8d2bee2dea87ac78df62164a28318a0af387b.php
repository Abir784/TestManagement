<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-10">
            <div class="card">

                <div class="card-body">
                    <div class="card-title">
                        <h3>Batch List</h3>
                    </div>

                    <table class="table table-striped">
                        <tr>
                            <th>#</th>
                            <th>Course Name</th>
                            <th>Batch Name</th>
                            <th>Start date</th>
                            <th>Action</th>
                        </tr>

                        <?php $__empty_1 = true; $__currentLoopData = $batch_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($batch->rel_to_course->name); ?></td>
                            <td><?php echo e($batch->batch_name); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($batch->start_date)->format('d,M-y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('batch.delete', $batch->id)); ?>" class="mr-2 btn btn-outline-danger btn-rounded show_confirm"> Delete</a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-warning"> No data to show</td>
                        </tr>

                        <?php endif; ?>


                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_code'); ?>
<?php if(session('success')): ?>
<script>
$(document).ready(function(){
    Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Your data has been deleted',
  showConfirmButton: false,
  timer: 2500
})
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/batches/batch_list.blade.php ENDPATH**/ ?>