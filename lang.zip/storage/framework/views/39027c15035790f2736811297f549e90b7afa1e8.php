<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(url('student/generate/marksheet_3')); ?>">Download Masrksheet</a>
                    </div>
                    <h5 class="card-title">
<pre>
Name:              <?php echo e($student->name); ?>

Registration No:   <?php echo e($student->registration_no); ?>

Course Name:       <?php echo e($student->course_name->name); ?>

Course code:       <?php echo e($student->course_name->course_code); ?>

Batch Number:      <?php echo e($student->batch_name->batch_name); ?>

</pre>
                    </h5>

                      <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>Test Name</th>
                                <th>Full Mark</th>
                                <th>Marks Obtained</th>
                                <th>GPA</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i=0;
                                $cgpa=0;

                            ?>
                            <?php $__currentLoopData = $quizzes_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $cgpa+=$result['gpa'];
                            $i+=1;

                            ?>
                            <tr>
                                <td><?php echo e($result['name']); ?></td>
                                <td><?php echo e($result['full_marks']); ?></td>
                                <td><?php echo e($result['mark_obtained']); ?></td>
                                <td><?php echo e(number_format($result['gpa'],2)); ?></td>
                                <td><?php echo e($result['grade']); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>


                      </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/individual_test/result_sheet.blade.php ENDPATH**/ ?>