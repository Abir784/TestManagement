<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(url('admin/index/invidual_test')); ?>" class="btn btn-primary mb-2"> Back</a>
                    <h4 class="card-title">Student List</h4>
                    <table class="table table-light">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = App\Models\IndividualTestStudents::where('quiz_id',$id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($students->student_name->name); ?></td>
                                <td><a href="" class="btn btn-danger">Delete</a></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td>No data found</td>
                            </tr>

                            <?php endif; ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <div class="card-title"><h5>Add Students</h5></div>
                    <form action="<?php echo e(route('individual.student.post')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="form-control form-control-rounded" value="<?php echo e($id); ?>"  name="quiz_id">

                        <div class="mb-3 form-group">
                            <label for="" class="form-label">Enter Registration No./Email:</label>
                            <input type="text" class="form-control form-control-rounded" value="<?php echo e(old('student_id')); ?>" name="student_id">
                            <?php if(session('error')): ?>
                            <p class="text-danger mt-2"> <?php echo e(session('error')); ?></p>
                          <?php endif; ?>
                        </div>

                        <div class="mb-3 form-group">
                            <button type="submit" class="btn btn-danger btn-danger-rounded">Submit</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/individual_test/student_add.blade.php ENDPATH**/ ?>