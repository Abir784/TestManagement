<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Add Questions(Specific)</h5>
                    <p class="card-text">


                        <a href="<?php echo e(route('quiz.course_based.question.index',$quiz_id)); ?>" class="btn btn-primary">Back</a>


                    </p>
                    <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
                                <th>Question Title</th>
                            </tr>
                        </thead>
                        <form action="<?php echo e(route('individual.add.quiz.question.post')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="quiz_id" value="<?php echo e($quiz_id); ?>">
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><input type="checkbox" class='' name="question_id[]" value="<?php echo e($question->id); ?>"></td>
                                        <td><?php echo $question->title; ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="2">
                                                  No Questions Added Yet
                                        </td>
                                    </tr>
                                <?php endif; ?>

                                <?php
                                  $count=count($questions)

                                ?>



                                <tr>
                                    <td>
                                        <?php if( $count != 0): ?>
                                        <button class="btn btn-success" type="submit">Submit </button>
                                        <?php endif; ?>
                                   </td>
                                </tr>
                            </tbody>


                        </form>


                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/individual_test/question_specific_add.blade.php ENDPATH**/ ?>