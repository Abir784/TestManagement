<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(url('student/generate/marksheet')); ?>">Download Marksheet</a>
                    </div>
                    <h5 class="card-title">
<pre>
Name:              <?php echo e($student->name); ?>

Registration No:   <?php echo e($student->registration_no); ?>

Course Name:       <?php echo e($student->course_name->name); ?>

Course code:       <?php echo e($student->course_name->course_code); ?>

Batch Number:      <?php echo e($student->batch_name->batch_name); ?>

</pre>
                    </h5>

                      <table class="table table-light">
                        <thead class="thead-light">
                            <tr>
                                <th>Test Name</th>
                                <th>Full Mark</th>
                                <th>Marks Obtained</th>
                                <th>GPA</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i=0;
                                $cgpa=0;

                            ?>
                            <?php $__currentLoopData = $quizzes_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $cgpa+=$result['gpa'];
                            $i+=1;

                            ?>
                            <tr>
                                <td><?php echo e($result['name']); ?></td>
                                <td><?php echo e($result['full_marks']); ?></td>
                                <td><?php echo e($result['mark_obtained']); ?></td>
                                <td><?php echo e(number_format($result['gpa'],2)); ?></td>
                                <td><?php echo e($result['grade']); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <thead class="thead-light">
                            <th colspan="5" class="text-center">Assignments</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $assignment_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $cgpa+=$result['gpa'];
                            $i+=1;
                            ?>
                                <tr>
                                    <td><?php echo e($result['name']); ?></td>
                                    <td><?php echo e($result['full_marks']); ?></td>
                                    <td><?php echo e($result['marks_obtained']); ?></td>
                                    <td><?php echo e(number_format($result['gpa'],2)); ?></td>
                                    <td><?php echo e($result['grade']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <thead class="thead-light">
                            <th colspan="5" class="text-center">CGPA(Out of 4)</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="5" class="text-center"><?php echo e(number_format($cgpa/$i,2)); ?></td>
                            </tr>
                        </tbody>
                        <thead class="thead-light">
                            <th colspan="5" class="text-center">Letter Grade</th>
                        </thead>
                        <tbody>
                            <?php if(($cgpa/$i) == 0): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('F'); ?></td>
                                </tr>
                            <?php elseif(($cgpa/$i) >= 2.50 && ($cgpa/$i) <=2.74 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('C+'); ?></td>
                                </tr>
                            <?php elseif(($cgpa/$i) >= 2.75 && ($cgpa/$i) <=2.99 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('B-'); ?></td>
                                </tr>
                             <?php elseif(($cgpa/$i) >= 3.00 && ($cgpa/$i) <=3.24 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('B'); ?></td>
                                </tr>
                            <?php elseif(($cgpa/$i) >= 3.25 && ($cgpa/$i) <=3.49 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('B+'); ?></td>
                                </tr>
                            <?php elseif(($cgpa/$i) >= 3.50 && ($cgpa/$i) <=3.74 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('A-'); ?></td>
                                </tr>
                             <?php elseif(($cgpa/$i) >= 3.75 && ($cgpa/$i) <=3.99 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('A'); ?></td>
                                </tr>
                            <?php elseif(($cgpa/$i) >= 4.00 ): ?>
                                <tr>
                                    <td colspan="5" class="text-center"><?php echo e('A+'); ?></td>
                                </tr>

                            <?php endif; ?>
                        </tbody>

                      </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.haeder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abir Hossain\OneDrive\Desktop\Projects\TestManagement\TestManagement\resources\views/course_based_test/result_sheet.blade.php ENDPATH**/ ?>