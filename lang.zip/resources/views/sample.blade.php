<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sample</title>
</head>
<body>
    <table>
        <tr>
            <th>Registration No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone No.</th>
            <th>Country</th>
        </tr>
        <tr>
            <td>12345678</td>
            <td>John Doe</td>
            <td>johndoe@gmail.com</td>
            <td>0134122541</td>
            <td>Bangladesh</td>
        </tr>
    </table>
</body>
</html>
